extern void make_matrix(unsigned int size, ...);
extern void check_matrix(unsigned int size, double **c, unsigned int number);
